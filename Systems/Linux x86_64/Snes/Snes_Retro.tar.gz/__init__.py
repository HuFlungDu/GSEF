from retro import core, exceptions

class CoreDoesNotExistError(Exception):
    pass

class system(object):
    def __init__(self):
        self.Core = None
        self.controls = None
        self.romename = None
        
    def load_core(self,CoreName):
        try:
            tcore = __import__("Core_" + CoreName)
            self.Core = tcore.core()
        except ImportError:
            raise CoreDoesNotExistError
        
    def unload_core(self):
        if self.Core:
            self.Core.unload()
            self.Core = None
        
    def load_game(self,gamepath, gamefile, patchpath, patcher):
        #Some kind of patching code here
        rompath = gamepath+gamefile
        savefile = gamepath+"savestates/savedata"
        self.romname = rompath
        if self.Core:
            return self.Core.load_game(rompath,savefile)
        else:
            return False

    def run_frame(self):
        if self.Core:
            self.Core.run_frame()
        else:
            return False

    def close(self):
        self.Core.unload()
        self.Core = None

    def update_controls(self,controldic):
        if self.Core:
            self.Core.update_controls(controldic)
        else:
            return False

    def get_framerate(self):
        return self.Core.get_framerate()

    def check_core(self):
        return bool(self.Core)

    def get_save_state_data(self):
        return self.Core.get_save_state_data()

    def load_state(self,savedata):
        self.Core.load_state(savedata)

    def save_data(self):
        if self.Core:
            savefolder = "{}/{}".format("/".join(self.romname.split("/")[:-1]),"savestates")
            self.Core.save_data(savefolder)
        
