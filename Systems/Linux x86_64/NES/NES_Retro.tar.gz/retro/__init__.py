"""
libretro-cython Python wrapper for libretro

Author: HuFlungDu
Licence: Beerware
Homepage: https://gitorious.org/libretro-cython

Adapted from the python-retro wrapper by lifning, which was itself
adapted from the python-snes wrapper by Timothy Allen <screwtape@froup.com>

To get started, you probably want to read the documentation for the "core"
module.
"""
