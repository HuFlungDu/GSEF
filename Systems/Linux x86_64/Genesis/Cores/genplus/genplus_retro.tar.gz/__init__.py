from retro import core as snes_core
from gi.repository import Clutter as clutter
from gi.repository import Cogl as cogl
import Callbacks
import time
from ctypes import *
import os
import numpy

def ReadBinaryFile(filename):
    rfile = open(filename,"rb")
    data = rfile.read()
    rfile.close()
    return data

class core(object):
    def __init__(self):
        
        #self.Tex = glGenTextures(1)
        olddir = os.getcwd()
        os.chdir("/".join(os.path.abspath(__file__).split("/")[:-1]))
        self.snes = snes_core.EmulatedSystem("./libretro-genplus.so")
        os.chdir(olddir)
        self.snes.set_video_refresh_cb(self.refresh_video)
        self.snes.set_audio_sample_batch_cb(self.audio_sample)
        self.snes.set_input_state_cb(self.input_state)
        self.frames = 0
        self.oldtime = time.time()
        self.frameskip = 1
        self.framerate = 0
        self.controls=None
        self.ports = ["Controller Port 1","Controller Port 2"]
        self.devices = [[None],["Gamepad"],["Multitap:Multitap Port 1:Gamepad","Multitap:Multitap Port 2:Gamepad","Multitap:Multitap Port 3:Gamepad", "Multitap:Multitap Port 4:Gamepad"],
                        ["Mouse"],["Super Scope"],
                        ["Justifiers:Justifier Port 1:Justifier"],["Justifiers:Justifier Port 1:Justifier","Justifiers:Justifier Port 2:Justifier"]]
        self.controllist = [
                            [[],                        #Port1, Empty
                            ["B","Y","Select","Start","Up","Down","Left","Right",
                                "A","X","Z","C"],       #Port1, game pad
                            ["B","Y","Select","Start","Up","Down","Left","Right",
                                "A","X","Z","C"],       #Port1, Multitap
                            ["X-Axis","Y-Axis","Left Button",
                                "Right Button"],         #Port1, Mouse
                            ],                          #Port1
                            [[],                        #Port2, Empty
                            ["B","Y","Select","Start","Up","Down","Left","Right",
                              "A","X","Z","C"],         #Port2, game pad
                             ["B","Y","Select","Start","Up","Down","Left","Right",
                              "A","X","L","R"],         #Port2, Multitap
                             ["X-Axis","Y-Axis","Left Button",
                              "Right Button"],           #Port2, Mouse
                             ["X-Axis","Y-Axis","Trigger",
                              "Cursor","Turbo"],         #Port2, Super Scope
                             ["X-Axis","Y-Axis",
                              "Trigger","Start"],        #Port2, Justifier
                             ["X-Axis","Y-Axis",
                              "Trigger","Start"]        #Port2, Justifiers
                             ]                          #Port2
                            ]                           #Controllist

    def unload(self):
        self.snes.close()

    def load_game(self,romname):
        self.game = ReadBinaryFile(romname)
        if len(self.game)%0x8000:
            self.game = self.game[0x200:]
        if self.snes._game_loaded:
            self.snes.unload()
        self.snes.load_game_normal(data=self.game, path=romname)
        return True

    def run_frame(self):
        self.snes.run()

    def refresh_video(self,data,width,height,pitch):
        frame_size = width*2 * height
        frame_buf = create_string_buffer(frame_size)
        #frame_buf = numpy.empty(frame_size,numpy.dtype("u1"))
        #print data.ctypes.data
        for i in xrange(height):
            memmove(addressof(frame_buf) + i * width *2,
                    data.ctypes.data + i * pitch,
                    width *2)
        Callbacks.UpdatePicture(frame_buf,width,height,pitch,"ABGR1555")
        
        '''frame_size = width*2 * height
        frame_buf = create_string_buffer(frame_size)
        if not self.frames%self.frameskip:
            for i in xrange(height):
                memmove(addressof(frame_buf) + i * width * 2,
                        addressof(data.contents) + i * pitch * 2,
                        width*2)
            glBindTexture(GL_TEXTURE_2D,self.Tex)
            glTexParameter(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
            glTexParameter(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_BGRA,
                         GL_UNSIGNED_SHORT_1_5_5_5_REV, frame_buf)
            Callbacks.UpdatePicture(self.Tex)'''

    def audio_sample(self,data,frames):
        Callbacks.UpdateAudio(data)
        return frames

    def input_poll(self):
        return
    def input_state(self, port, device, index, identity):
        if port < 2:
            buttoncheck = self.controls[self.ports[port]]
            for i in self.devices[device][index].split(":"):
                buttoncheck = buttoncheck[i]
            buttoncheck = buttoncheck[self.controllist[port][device][identity]]
            return buttoncheck.get_state()
        else:
            return 0

    def ReadFile(filename):
        readfile = open(filename,'r')
        source = readfile.read()
        readfile.close()
        return source
    def ReadBinaryFile(filename):
        readfile = open(filename,'rb')
        source = readfile.read()
        readfile.close()
        return source


    def update_controls(self,controldic):
        self.controls = controldic

    def get_framerate(self):
        return self.snes.get_refresh_rate()

    def get_save_state_data(self):
        return self.snes.serialize()

    def load_state(self, savedata):
        self.snes.unserialize(savedata)

    def save_data(self, savepath):
        savedata = self.snes.get_save_data()
        with open("{}/{}".format(savepath,"savedata"),"w") as savefile:
            savefile.write(savedata)
