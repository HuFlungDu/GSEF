"""
Implementations of the video refresh callback, for various back-ends.
"""
